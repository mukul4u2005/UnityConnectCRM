<?php

// key and orgID provided here are for valid 'demo' eGive data
// 64 character 'alpha' key provided by eGive
//              0123456789012345678901234567890123456789012345678901234567890123
$eGiveApiKey = '6ebef5c8c0848a7091ba23f68d06770c1476ccc169f2ade3be2952fc03de4cd7';
$eGiveURL = 'https://www.egive-usa.com';

// specific number for your church
$eGiveOrgID = 13821;
