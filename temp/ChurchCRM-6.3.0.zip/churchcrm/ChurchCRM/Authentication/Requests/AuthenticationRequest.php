<?php

namespace ChurchCRM\Authentication\Requests;

abstract class AuthenticationRequest
{
}
