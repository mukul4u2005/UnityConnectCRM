<?php

namespace ChurchCRM\Backup;

class JobBase
{
    protected string $BackupType;
}
