<?php

namespace ChurchCRM\dto;

abstract class KioskAssignmentTypes
{
    public const EVENTATTENDANCEKIOSK = 1;
    public const SELFREGISTRATIONKIOSK = 2;
    public const SELFCHECKINKIOSK = 3;
    public const GENERALATTENDANCEKIOSK = 4;
}
